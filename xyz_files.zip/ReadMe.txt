The (x,y,z) coordinates were scaled using interatomic distances of 2.543 A (copper) and 2.874 A (gold).
